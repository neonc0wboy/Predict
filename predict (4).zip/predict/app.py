import os
import subprocess
import requests
from flask import Flask, request, jsonify, render_template
from mnemonic import Mnemonic
from dotenv import load_dotenv

# --- 1. Configuration ---
# Load environment variables from the .env file
load_dotenv()

# Initialize the Flask application
app = Flask(__name__)
app.json.ensure_ascii = False

# Get the API Key from the environment. The app will fail to start if it's not set.
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError("No GOOGLE_API_KEY set in the .env file or environment variables")

# We use gemini-1.5-flash as it's a fast and capable model
GEMINI_MODEL = "gemini-2.5-flash"
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"

# --- Authentication & Themes (Unchanged) ---
VALID_INVITE_CODES = {"SECRET123", "MAGIC_KEY", "COWBOY_CODE"}
PROMPT_TEMPLATES = {
    "Tarot": (
        "предскажи будущее для '{user_name}' на '{prediction_date}', "
        "он(она) является '{relationship}' для CH aka meta.c0wb0y. "
        "Используй следующие слова словно эти слова выпали при раскладе карт Таро: '{magic_words}'"
    ),
    "Runes": (
        "Дайте мистическое предсказание для '{user_name}' на дату '{prediction_date}'."
        "Они являются '{relationship}' для СН, также известного как meta.c0wb0y."
        "Интерпретируйте эти слова так, как если бы они были древними норвежскими рунами, вырезанными на камне: '{magic_words}'"
    ),
    "Sci-Fi": (
"Из центральных баз данных ИИ, сгенерировать системную проекцию для человека, известного как '{user_name}', на звездную дату '{prediction_date}'."
"Их отношение к системному оператору 'meta.c0wb0y' зафиксировано как '{relationship}'."
"Обработать следующие фрагменты данных из поврежденного файла журнала в качестве основы для проекции: '{magic_words}'"
    )
}

mnemo = Mnemonic("russian")
mnemo1 = Mnemonic("english")

def generate_mnemonic_words():
    entropy = os.urandom(16)
    return str(f"{mnemo.to_mnemonic(entropy)}{' '}{mnemo1.to_mnemonic(entropy)}")

#mnemo = Mnemonic("english")
#mnemo = Mnemonic("russian")
def get_prediction_from_gemini(prompt: str) -> str:
    """
    Gets a prediction by calling the Google Gemini API directly.
    """
    headers = {
        'Content-Type': 'application/json',
        'X-goog-api-key': GOOGLE_API_KEY
    }
    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": prompt
                    }
                ]
            }
        ]
    }
    try:
        response = requests.post(GEMINI_API_URL, headers=headers, json=payload, timeout=90)
        response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
        # Safely parse the response to get the prediction text
        json_response = response.json()
        prediction = json_response['candidates'][0]['content']['parts'][0]['text']
        return prediction.strip()
    except requests.exceptions.RequestException as e:
        print(f"Gemini API request failed: {e}")
        raise RuntimeError("Failed to connect to the Gemini API.")
    except (KeyError, IndexError) as e:
        print(f"Could not parse Gemini response: {e}")
        # Log the full response for debugging
        print(f"Full Gemini response: {response.text}")
        raise RuntimeError("Received an invalid response from the Gemini API.")


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def get_prediction():
    data = request.get_json()
    # Basic validation
    if not all(k in data for k in ['name', 'theme', 'date_for', 'invite_code']):
        return jsonify({"error": "Missing required fields."}), 400
    if data['invite_code'] not in VALID_INVITE_CODES:
        return jsonify({"error": "A valid invite_code is required."}), 403
    # Construct the prompt (unchanged)
    prompt_template = PROMPT_TEMPLATES.get(data['theme'], PROMPT_TEMPLATES)
    magic_words = generate_mnemonic_words()
    prompt = prompt_template.format(
        user_name=data['name'],
        #prediction_date="ближайшее будущее",
        prediction_date=data['date_for'],
        relationship="по отношению к СН(meta.c0wb0y/neonc0wboy/c0wb0y)",
        magic_words=magic_words
    )
    prediction_text = ""
    # --- 3. The Fallback Logic ---
    #try:
        # First, try to use tgpt
       # command = ["tgpt", "-s", "-w", prompt]
        #result = subprocess.run(command, capture_output=True, text=True, check=True, timeout=120)
        #prediction_text = result.stdout.strip()
        #print("Successfully generated prediction using tgpt.")
    #except FileNotFoundError:
        # This error means the 'tgpt' command does not exist.
       # print("tgpt command not found. Falling back to Gemini API.")
    try:
            # So, we call our new Gemini function
        prediction_text = get_prediction_from_gemini(prompt)
        print("Successfully generated prediction using Gemini API.")
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 500
    #except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        # Handle other errors from tgpt
        #return jsonify({"error": f"The tgpt command failed: {e}"}), 500
    return jsonify({
        "prediction_for": data['name'],
        "prediction": prediction_text,
        "seed_words": magic_words,
        "theme": data['theme']
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8133, debug=True)
